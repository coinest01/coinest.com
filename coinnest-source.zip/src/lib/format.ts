const usdFormatter = new Intl.NumberFormat("en-US", {
  style: "currency",
  currency: "USD",
  maximumFractionDigits: 2,
});

const usdCompactFormatter = new Intl.NumberFormat("en-US", {
  style: "currency",
  currency: "USD",
  notation: "compact",
  maximumFractionDigits: 1,
});

const numberFormatter = new Intl.NumberFormat("en-US", {
  maximumFractionDigits: 2,
});

/** $1,234.56 */
export function formatUSD(value: number) {
  return usdFormatter.format(value);
}

/** $1.2K */
export function formatUSDCompact(value: number) {
  return usdCompactFormatter.format(value);
}

/** 1,234.5 */
export function formatNumber(value: number) {
  return numberFormatter.format(value);
}

const relativeFormatter = new Intl.RelativeTimeFormat("en", {
  numeric: "auto",
});

/** "2h ago", "3d ago", "just now" */
export function timeAgo(timestamp: number, now = Date.now()) {
  const seconds = Math.round((timestamp - now) / 1000);
  const abs = Math.abs(seconds);
  const units: [Intl.RelativeTimeFormatUnit, number][] = [
    ["year", 60 * 60 * 24 * 365],
    ["month", 60 * 60 * 24 * 30],
    ["week", 60 * 60 * 24 * 7],
    ["day", 60 * 60 * 24],
    ["hour", 60 * 60],
    ["minute", 60],
  ];
  for (const [unit, secondsPerUnit] of units) {
    if (abs >= secondsPerUnit) {
      return relativeFormatter.format(
        Math.round(seconds / secondsPerUnit),
        unit,
      );
    }
  }
  return "just now";
}

/** 25% */
export function formatPercent(value: number) {
  return `${Math.round(value)}%`;
}
