import { getAuthUserId } from "@convex-dev/auth/server";
import { ConvexError, v } from "convex/values";
import { MutationCtx, mutation } from "./_generated/server";
import type { Id } from "./_generated/dataModel";

// Whitelist of events that may be recorded. Keeping this server-side means a
// caller can never invent log entries — only the app's own code paths can.
export const AUDIT_EVENTS = [
  "login",
  "login_guest",
  "logout",
  "saving_added",
  "saving_deleted",
  "goal_created",
  "goal_completed_toggled",
  "goal_deleted",
] as const;

const MAX_DETAIL_LENGTH = 200;

/**
 * Server-side helper: appends an audit log row inside the current mutation's
 * transaction. Only call from authenticated Convex functions.
 */
export async function writeAuditLog(
  ctx: MutationCtx,
  userId: Id<"users">,
  event: (typeof AUDIT_EVENTS)[number],
  detail?: string,
) {
  const cleanDetail = detail?.trim().slice(0, MAX_DETAIL_LENGTH) || undefined;
  await ctx.db.insert("auditLogs", { userId, event, detail: cleanDetail });
}

/**
 * Client-facing entry point used right after a successful sign-in/sign-out,
 * when the user's session is already active.
 */
export const logAuditEvent = mutation({
  args: {
    event: v.string(),
    detail: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (userId === null) {
      throw new ConvexError("Please sign in first.");
    }
    if (!(AUDIT_EVENTS as readonly string[]).includes(args.event)) {
      throw new ConvexError("Invalid audit event.");
    }
    const detail = args.detail?.trim().slice(0, MAX_DETAIL_LENGTH) || undefined;
    await ctx.db.insert("auditLogs", { userId, event: args.event, detail });
  },
});
