import { getAuthUserId } from "@convex-dev/auth/server";
import { v } from "convex/values";
import { mutation, query } from "./_generated/server";

// ---------------------------------------------------------------------------
// Limits & entitlements (shared with aiActions.ts — keep in sync)
// ---------------------------------------------------------------------------

export const AI_LIMITS = {
  FREE_DAILY: 3, // free-tier teaser quota (used once pricing launches)
  PREMIUM_DAILY: 10, // the premium entitlement the owner asked for
} as const;

// Payments aren't live yet, so every signed-in user currently gets the premium
// quota. When pricing ships, flip this to true and mark free users accordingly.
const ENFORCE_PREMIUM = false;

function todayKey() {
  return new Date().toISOString().slice(0, 10);
}

// ---------------------------------------------------------------------------
// Daily usage (reactive — the UI shows live counters)
// ---------------------------------------------------------------------------

export const getDailyUsage = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (userId === null) {
      return null;
    }
    const user = await ctx.db.get(userId);
    const isPremium = ENFORCE_PREMIUM ? Boolean(user?.isPremium) : true;
    const limit = isPremium ? AI_LIMITS.PREMIUM_DAILY : AI_LIMITS.FREE_DAILY;
    const row = await ctx.db
      .query("aiUsage")
      .withIndex("by_user_date", (q) =>
        q.eq("userId", userId).eq("date", todayKey()),
      )
      .first();
    return {
      isPremium,
      limit,
      coachUsed: row?.coachCount ?? 0,
      signalsUsed: row?.signalsCount ?? 0,
    };
  },
});

// ---------------------------------------------------------------------------
// Internal mutations (called by the actions via ctx.runMutation)
// ---------------------------------------------------------------------------

/** Bumps today's counter for the signed-in user. Auth-scoped — never trusts a userId from the caller. */
export const recordUseInternal = mutation({
  args: { kind: v.union(v.literal("coach"), v.literal("signals")) },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (userId === null) return;
    const row = await ctx.db
      .query("aiUsage")
      .withIndex("by_user_date", (q) =>
        q.eq("userId", userId).eq("date", todayKey()),
      )
      .first();
    if (row) {
      await ctx.db.patch(row._id, {
        coachCount: row.coachCount + (args.kind === "coach" ? 1 : 0),
        signalsCount: row.signalsCount + (args.kind === "signals" ? 1 : 0),
      });
    } else {
      await ctx.db.insert("aiUsage", {
        userId,
        date: todayKey(),
        coachCount: args.kind === "coach" ? 1 : 0,
        signalsCount: args.kind === "signals" ? 1 : 0,
      });
    }
  },
});

/** Records a per-request cost log row ("track cost per request" from the ops playbook). */
export const logAiCallInternal = mutation({
  args: {
    kind: v.union(v.literal("coach"), v.literal("signals")),
    prompt: v.optional(v.string()),
    model: v.optional(v.string()),
    tokensIn: v.number(),
    tokensOut: v.number(),
    costUsd: v.number(),
    latencyMs: v.number(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (userId === null) return;
    await ctx.db.insert("aiCalls", {
      userId,
      kind: args.kind,
      prompt: args.prompt?.slice(0, 200),
      model: args.model,
      tokensIn: args.tokensIn,
      tokensOut: args.tokensOut,
      costUsd: Number(args.costUsd.toFixed(6)),
      latencyMs: args.latencyMs,
    });
  },
});
