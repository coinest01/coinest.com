"use node";

import { getAuthUserId } from "@convex-dev/auth/server";
import { ConvexError, v } from "convex/values";
import { api } from "./_generated/api";
import { action } from "./_generated/server";

// Keep in sync with src/convex/ai.ts
const AI_LIMITS = {
  FREE_DAILY: 3,
  PREMIUM_DAILY: 10,
} as const;

// Estimated Perplexity "sonar" pricing (USD per 1M tokens). Used only for the
// per-request cost log; update these to match the plan when it changes.
const COST_PER_M_IN = 1.0;
const COST_PER_M_OUT = 2.0;

const QUESTION_MAX = 200;

// Well-known meme coins used to filter CoinGecko's trending list.
const MEME_SYMBOLS = new Set([
  "DOGE", "SHIB", "PEPE", "BONK", "WIF", "FLOKI", "BRETT", "MOG", "PENGU",
  "MEW", "TURBO", "DOGS", "NEIRO", "KISHU", "BABYDOGE", "ELON", "SPX", "GIGA",
  "POPCAT", "MOODENG", "CHEEMS", "WEN", "MYRO", "MAGA", "TOSHI", "BOME",
  "SLERF", "DEGEN", "MEME", "COQ", "CORGIAI", "MOON", "PEPECOIN", "PONKE",
]);

// ---------------------------------------------------------------------------
// Shared helpers
// ---------------------------------------------------------------------------

function startOfLocalDay(timestamp: number) {
  const d = new Date(timestamp);
  return new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime();
}

/**
 * OpenAI-compatible call to Perplexity's Sonar API using plain fetch (no extra
 * dependency). Env-gated: without PERPLEXITY_API_KEY the feature reports a
 * friendly "not configured" error instead of crashing.
 */
async function callPerplexity(system: string, userPrompt: string) {
  const apiKey = process.env.PERPLEXITY_API_KEY;
  if (!apiKey) {
    throw new ConvexError(
      "AI features aren't configured yet — the app owner needs to add the PERPLEXITY_API_KEY in the Keys tab.",
    );
  }
  const started = Date.now();
  let res: Response;
  try {
    res = await fetch("https://api.perplexity.ai/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "sonar",
        messages: [
          { role: "system", content: system },
          { role: "user", content: userPrompt },
        ],
        max_tokens: 240,
        temperature: 0.4,
      }),
    });
  } catch {
    throw new ConvexError(
      "Couldn't reach the AI service. Please try again in a moment.",
    );
  }
  const latencyMs = Date.now() - started;
  if (!res.ok) {
    throw new ConvexError(
      `The AI service returned an error (${res.status}). Please try again shortly.`,
    );
  }
  const json = (await res.json()) as {
    choices?: { message?: { content?: string } }[];
    usage?: { prompt_tokens?: number; completion_tokens?: number };
  };
  const content = (json?.choices?.[0]?.message?.content ?? "").trim();
  const tokensIn = json?.usage?.prompt_tokens ?? 0;
  const tokensOut = json?.usage?.completion_tokens ?? 0;
  const costUsd =
    (tokensIn / 1_000_000) * COST_PER_M_IN +
    (tokensOut / 1_000_000) * COST_PER_M_OUT;
  return { content, tokensIn, tokensOut, costUsd, latencyMs };
}

// ---------------------------------------------------------------------------
// AI Coach
// ---------------------------------------------------------------------------

const COACH_SYSTEM = [
  "You are the CoinNest savings coach, a warm, encouraging guide for beginner",
  "crypto savers. Answer in 2-4 short sentences, plain language, no jargon.",
  "Ground every answer in the user's real numbers provided below. Never give",
  "investment advice, price predictions, or tax advice. If asked something",
  "outside savings habits, gently steer back to saving consistently.",
].join(" ");

export const getCoachInsight = action({
  args: { question: v.string() },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (userId === null) {
      throw new ConvexError("Please sign in to use the AI Coach.");
    }

    const question = args.question.trim().slice(0, QUESTION_MAX);
    if (!question) {
      throw new ConvexError("Ask the coach something first.");
    }

    // Enforce the daily limit server-side (auth forwards through runQuery).
    const usage = await ctx.runQuery(api.ai.getDailyUsage);
    const limit = usage?.limit ?? AI_LIMITS.PREMIUM_DAILY;
    if ((usage?.coachUsed ?? 0) >= limit) {
      throw new ConvexError(
        `You've used all ${limit} AI Coach requests for today. Come back tomorrow!`,
      );
    }

    // Build a compact snapshot of the user's own savings data.
    const savings = (await ctx.runQuery(api.savings.mySavings)) ?? [];
    const goals = (await ctx.runQuery(api.savings.myGoals)) ?? [];

    const now = new Date();
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1).getTime();
    let total = 0;
    let thisMonth = 0;
    for (const s of savings) {
      total += s.amountUsd;
      if (s._creationTime >= startOfMonth) thisMonth += s.amountUsd;
    }
    const byAsset = new Map<string, number>();
    for (const s of savings) {
      byAsset.set(s.asset, (byAsset.get(s.asset) ?? 0) + s.amountUsd);
    }
    const topAsset =
      [...byAsset.entries()].sort((a, b) => b[1] - a[1])[0]?.[0] ?? "none yet";
    const dayMs = 86_400_000;
    const days = new Set(savings.map((s) => startOfLocalDay(s._creationTime)));
    let streak = 0;
    let cursor = startOfLocalDay(Date.now());
    if (!days.has(cursor)) cursor -= dayMs;
    while (days.has(cursor)) {
      streak += 1;
      cursor -= dayMs;
    }
    const completedGoals = goals.filter((g) => g.completed).length;

    const context = [
      `Total saved: $${total.toFixed(2)} (${savings.length} entries).`,
      `Saved this month: $${thisMonth.toFixed(2)}.`,
      `Current day streak: ${streak}.`,
      `Most-saved coin: ${topAsset}.`,
      `Goals: ${goals.length} total, ${completedGoals} completed.`,
      goals.length > 0
        ? `Next goal: ${goals[0].name} ($${goals[0].targetUsd.toFixed(2)}).`
        : "No goals set yet.",
    ].join(" ");

    const result = await callPerplexity(
      COACH_SYSTEM,
      `User's savings snapshot: ${context}\n\nUser's question: ${question}`,
    );

    await ctx.runMutation(api.ai.logAiCallInternal, {
      kind: "coach",
      prompt: question,
      model: "sonar",
      tokensIn: result.tokensIn,
      tokensOut: result.tokensOut,
      costUsd: result.costUsd,
      latencyMs: result.latencyMs,
    });
    await ctx.runMutation(api.ai.recordUseInternal, { kind: "coach" });

    return { text: result.content };
  },
});

// ---------------------------------------------------------------------------
// Meme Signal board (data-driven — free CoinGecko API, no LLM cost)
// ---------------------------------------------------------------------------

interface MemeSignal {
  id: string;
  name: string;
  symbol: string;
  price: number | null;
  change24h: number | null;
  marketCapUsd: number | null;
  trendRank: number;
  score: number;
  reason: string;
}

export const getMemeSignals = action({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (userId === null) {
      throw new ConvexError("Please sign in to see meme signals.");
    }

    const usage = await ctx.runQuery(api.ai.getDailyUsage);
    const limit = usage?.limit ?? AI_LIMITS.PREMIUM_DAILY;
    if ((usage?.signalsUsed ?? 0) >= limit) {
      throw new ConvexError(
        `You've used all ${limit} signal requests for today. Come back tomorrow!`,
      );
    }

    let trending: unknown;
    try {
      const res = await fetch("https://api.coingecko.com/api/v3/search/trending");
      if (!res.ok) {
        throw new Error(`CoinGecko status ${res.status}`);
      }
      trending = await res.json();
    } catch {
      throw new ConvexError(
        "Couldn't reach market data right now. Please try again in a minute.",
      );
    }

    const coins = (trending as { coins?: { item?: unknown }[] })?.coins ?? [];
    const signals: MemeSignal[] = [];

    coins.forEach((entry, index) => {
      const item = (entry?.item ?? {}) as Record<string, unknown>;
      const symbol = String(item.symbol ?? "").toUpperCase();
      if (!MEME_SYMBOLS.has(symbol)) return;
      const data = (item.data ?? {}) as Record<string, unknown>;
      const price = typeof data.price === "number" ? data.price : null;
      const changeRaw = (data.price_change_percentage_24h as
        | { usd?: number }
        | undefined)?.usd;
      const change24h = typeof changeRaw === "number" ? changeRaw : null;
      const mcapRaw = (data.market_cap as { usd?: unknown } | undefined)?.usd;
      const marketCapUsd =
        typeof mcapRaw === "number"
          ? mcapRaw
          : typeof mcapRaw === "string"
            ? Number(mcapRaw.replace(/[^0-9.]/g, "")) || null
            : null;

      // Simple momentum score: trending position (0-15) + 24h move (0-40).
      const trendPoints = Math.max(0, 15 - index);
      const changePoints =
        change24h === null ? 0 : Math.max(0, Math.min(40, change24h));
      const score = Math.round(trendPoints + changePoints);

      signals.push({
        id: String(item.id ?? symbol),
        name: String(item.name ?? symbol),
        symbol,
        price,
        change24h,
        marketCapUsd,
        trendRank: index + 1,
        score,
        reason: `Trending #${index + 1} on CoinGecko · ${
          change24h === null
            ? "no 24h data"
            : `${change24h >= 0 ? "+" : ""}${change24h.toFixed(1)}% in 24h`
        }`,
      });
    });

    signals.sort((a, b) => b.score - a.score);

    await ctx.runMutation(api.ai.recordUseInternal, { kind: "signals" });

    return {
      signals: signals.slice(0, 5),
      generatedAt: Date.now(),
    };
  },
});
