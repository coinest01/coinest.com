import { ConvexError, v } from "convex/values";
import { action } from "./_generated/server";

/**
 * Server-side Cloudflare Turnstile verification (bot protection).
 *
 * The secret key is read from the TURNSTILE_SECRET_KEY environment variable.
 * When it's not configured, the check is skipped so sign-in keeps working —
 * the challenge simply isn't enforced until the key is added.
 */
export const verifyBotChallenge = action({
  args: { token: v.string() },
  handler: async (_ctx, args) => {
    const secret = process.env.TURNSTILE_SECRET_KEY;
    if (!secret) {
      return { ok: true, disabled: true };
    }
    if (!args.token) {
      throw new ConvexError("Security check incomplete. Please try again.");
    }

    const response = await fetch(
      "https://challenges.cloudflare.com/turnstile/v0/siteverify",
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ secret, response: args.token }),
      },
    );
    const data = (await response.json()) as {
      success?: boolean;
      "error-codes"?: string[];
    };

    if (!data.success) {
      console.error("Turnstile verification failed:", data["error-codes"]);
      throw new ConvexError(
        "We couldn't verify you're human. Please try again.",
      );
    }
    return { ok: true, disabled: false };
  },
});
