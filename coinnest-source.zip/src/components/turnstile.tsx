import { useEffect, useRef } from "react";

declare global {
  interface Window {
    turnstile?: {
      render: (
        container: HTMLElement,
        options: {
          sitekey: string;
          theme?: "light" | "dark" | "auto";
          callback?: (token: string) => void;
          "expired-callback"?: () => void;
          "error-callback"?: () => void;
        },
      ) => string;
      remove: (widgetId: string) => void;
    };
  }
}

const SITE_KEY = import.meta.env.VITE_TURNSTILE_SITE_KEY as
  | string
  | undefined;

const SCRIPT_ID = "cf-turnstile-script";

interface TurnstileProps {
  onToken: (token: string | null) => void;
}

/**
 * Cloudflare Turnstile bot-protection challenge for the sign-in form.
 * - When VITE_TURNSTILE_SITE_KEY is not set, renders nothing and reports
 *   `null` (bot protection disabled) so sign-in is never blocked.
 * - When set, loads Cloudflare's script on demand and renders the widget.
 */
export function Turnstile({ onToken }: TurnstileProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const widgetIdRef = useRef<string | null>(null);
  const onTokenRef = useRef(onToken);
  onTokenRef.current = onToken;

  useEffect(() => {
    if (!SITE_KEY) {
      onTokenRef.current(null);
      return;
    }

    let cancelled = false;

    const loadScript = () =>
      new Promise<void>((resolve) => {
        if (document.getElementById(SCRIPT_ID)) {
          resolve();
          return;
        }
        const script = document.createElement("script");
        script.id = SCRIPT_ID;
        script.src =
          "https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit";
        script.async = true;
        script.onload = () => resolve();
        // If the script can't load, fall back to allowing the sign-in through
        // (the server-side check is skipped when no secret key is set anyway).
        script.onerror = () => resolve();
        document.head.appendChild(script);
      });

    void loadScript().then(() => {
      if (cancelled || !containerRef.current || !window.turnstile) {
        if (!cancelled) onTokenRef.current(null);
        return;
      }
      const widgetId = window.turnstile.render(containerRef.current, {
        sitekey: SITE_KEY,
        theme: "auto",
        callback: (token: string) => onTokenRef.current(token),
        "expired-callback": () => onTokenRef.current(null),
        "error-callback": () => onTokenRef.current(null),
      });
      widgetIdRef.current = widgetId;
    });

    return () => {
      cancelled = true;
      if (widgetIdRef.current && window.turnstile) {
        try {
          window.turnstile.remove(widgetIdRef.current);
        } catch {
          // widget may already be gone
        }
      }
    };
  }, []);

  if (!SITE_KEY) return null;

  return (
    <div
      ref={containerRef}
      className="mt-4 flex min-h-[65px] w-full justify-center"
    />
  );
}
