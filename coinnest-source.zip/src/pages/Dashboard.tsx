import { useCallback, useEffect, useMemo, useState } from "react";
import { useQuery } from "convex/react";
import { Link, useNavigate } from "react-router";
import { format, startOfDay, subDays } from "date-fns";
import {
  CalendarDays,
  Download,
  Flame,
  LogOut,
  PiggyBank,
  ShieldCheck,
  Sparkles,
  Target,
  Trash2,
  TrendingUp,
} from "lucide-react";

import { api } from "@/convex/_generated/api";
import type { Doc } from "@/convex/_generated/dataModel";
import { useAuth } from "@/hooks/use-auth";
import { useIdleSignout } from "@/hooks/use-idle-signout";
import { LogoWordmark } from "@/components/logo";
import { AddSavingDialog } from "@/components/dashboard/add-saving-dialog";
import { AICoach } from "@/components/dashboard/ai-coach";
import { GoalsSection } from "@/components/dashboard/goals-section";
import { MemeSignals } from "@/components/dashboard/meme-signals";
import { SavingsChart } from "@/components/dashboard/savings-chart";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";
import { formatUSD, timeAgo } from "@/lib/format";
import { toast } from "sonner";
import { useMutation } from "convex/react";

type SavingDoc = Doc<"savings">;

function computeStats(savings: SavingDoc[]) {
  const now = new Date();
  const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1).getTime();
  const startOfPrevMonth = new Date(
    now.getFullYear(),
    now.getMonth() - 1,
    1,
  ).getTime();
  let total = 0;
  let thisMonth = 0;
  let lastMonth = 0;
  for (const s of savings) {
    total += s.amountUsd;
    if (s._creationTime >= startOfMonth) thisMonth += s.amountUsd;
    else if (s._creationTime >= startOfPrevMonth) lastMonth += s.amountUsd;
  }
  const changePct =
    lastMonth > 0 ? ((thisMonth - lastMonth) / lastMonth) * 100 : null;
  return { total, thisMonth, lastMonth, changePct };
}

function computeStreak(savings: SavingDoc[]) {
  const days = new Set(savings.map((s) => startOfDay(s._creationTime).getTime()));
  let streak = 0;
  let cursor = startOfDay(Date.now()).getTime();
  if (!days.has(cursor)) cursor = subDays(cursor, 1).getTime();
  while (days.has(cursor)) {
    streak += 1;
    cursor = subDays(cursor, 1).getTime();
  }
  return streak;
}

function buildChartData(savings: SavingDoc[]) {
  const sorted = [...savings].sort(
    (a, b) => a._creationTime - b._creationTime,
  );
  const byDay = new Map<string, number>();
  for (const s of sorted) {
    const key = format(s._creationTime, "MMM d");
    byDay.set(key, (byDay.get(key) ?? 0) + s.amountUsd);
  }
  let running = 0;
  return [...byDay.entries()].map(([date, sum]) => ({
    date,
    total: (running += sum),
  }));
}

function greeting() {
  const hour = new Date().getHours();
  if (hour < 12) return "Good morning";
  if (hour < 18) return "Good afternoon";
  return "Good evening";
}

function downloadCsv(filename: string, rows: (string | number)[][]) {
  const csv = rows.map((r) => r.map((c) => {
    const s = String(c ?? "");
    return s.includes(",") || s.includes('"') || s.includes("\n")
      ? `"${s.replace(/"/g, '""')}"`
      : s;
  }).join(",")).join("\n");
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

export default function Dashboard() {
  const { user, signOut } = useAuth();
  const navigate = useNavigate();
  const savings = useQuery(api.savings.mySavings);
  const goals = useQuery(api.savings.myGoals);
  const exportData = useQuery(api.savings.exportData);
  const deleteSaving = useMutation(api.savings.deleteSaving);
  const logAudit = useMutation(api.audit.logAuditEvent);
  useIdleSignout();

  // Connection fallback: if Convex queries stay undefined for 15s, show retry UI
  const [connectionTimedOut, setConnectionTimedOut] = useState(false);
  useEffect(() => {
    if (savings !== undefined || goals !== undefined) {
      setConnectionTimedOut(false);
      return;
    }
    const timer = setTimeout(() => {
      setConnectionTimedOut(true);
    }, 15_000);
    return () => clearTimeout(timer);
  }, [savings, goals]);

  const loading = savings === undefined || goals === undefined;
  const savingsList = savings ?? [];
  const goalsList = goals ?? [];

  const stats = useMemo(() => computeStats(savingsList), [savingsList]);
  const streak = useMemo(() => computeStreak(savingsList), [savingsList]);
  const chartData = useMemo(() => buildChartData(savingsList), [savingsList]);
  const savedByGoal = useMemo(() => {
    const map: Record<string, number> = {};
    for (const s of savingsList) {
      if (s.goalId) map[s.goalId] = (map[s.goalId] ?? 0) + s.amountUsd;
    }
    return map;
  }, [savingsList]);

  const handleSignOut = async () => {
    void logAudit({ event: "logout" }).catch(() => {});
    await signOut();
    navigate("/");
  };

  const handleDeleteSaving = async (id: string) => {
    try {
      await deleteSaving({ id: id as Doc<"savings">["_id"] });
      toast.success("Entry removed.");
    } catch {
      toast.error("Couldn't remove that entry.");
    }
  };

  const handleExport = useCallback(() => {
    if (!exportData) {
      toast.error("Data is still loading, please try again.");
      return;
    }
    const { savings: s, goals: g } = exportData;
    // Savings CSV
    downloadCsv(
      "coinnest-savings.csv",
      [
        ["Date", "Asset", "Amount (USD)", "Asset Amount", "Note"],
        ...s.map((row) => [
          row.date,
          row.asset,
          row.amountUsd,
          row.assetAmount ?? "",
          row.note ?? "",
        ]),
      ],
    );
    // Goals CSV
    downloadCsv(
      "coinnest-goals.csv",
      [
        ["Goal Name", "Target (USD)", "Completed"],
        ...g.map((row) => [
          row.name,
          row.targetUsd,
          row.completed ? "Yes" : "No",
        ]),
      ],
    );
    toast.success("Your data has been downloaded.");
    void logAudit({ event: "data_export" }).catch(() => {});
  }, [exportData, logAudit]);

  const displayName =
    user?.name || (user?.email ? user.email.split("@")[0] : "saver");
  const firstName = displayName.split(" ")[0];
  const activeGoals = goalsList.filter((g) => !g.completed).length;
  const completedGoals = goalsList.length - activeGoals;
  const isFirstRun = !loading && savingsList.length === 0 && goalsList.length === 0;

  const statCards = [
    {
      label: "Total saved",
      value: formatUSD(stats.total),
      sub: "your nest egg, all time",
      icon: PiggyBank,
      accent: "bg-primary/10 text-primary",
    },
    {
      label: "Saved this month",
      value: formatUSD(stats.thisMonth),
      sub:
        stats.changePct !== null
          ? `${stats.changePct >= 0 ? "+" : ""}${Math.round(
              stats.changePct,
            )}% vs last month`
          : "no savings last month yet",
      icon: TrendingUp,
      accent: "bg-sky-500/10 text-sky-600 dark:text-sky-400",
    },
    {
      label: "Day streak",
      value: `${streak} ${streak === 1 ? "day" : "days"}`,
      sub: streak > 0 ? "keep it alive — log today" : "log a save to start one",
      icon: Flame,
      accent: "bg-amber-500/10 text-amber-600 dark:text-amber-400",
    },
    {
      label: "Active goals",
      value: String(activeGoals),
      sub: `${completedGoals} completed`,
      icon: Target,
      accent: "bg-indigo-500/10 text-indigo-600 dark:text-indigo-400",
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-40 border-b border-border/70 bg-background/85 backdrop-blur">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-3 px-4 sm:px-6">
          <Link
            to="/"
            className="rounded-lg transition-opacity hover:opacity-80"
          >
            <LogoWordmark markClassName="size-8" />
          </Link>
          <div className="flex items-center gap-2">
            <AddSavingDialog goals={goalsList} />
            <Button
              variant="ghost"
              size="icon"
              onClick={handleExport}
              aria-label="Export data"
              className="text-muted-foreground hover:text-foreground"
              title="Download your data as CSV"
            >
              <Download className="size-4" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={handleSignOut}
              aria-label="Sign out"
              className="text-muted-foreground hover:text-foreground"
            >
              <LogOut className="size-4" />
            </Button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-4 pb-24 pt-8 sm:px-6">
        {/* Connection error fallback */}
        {connectionTimedOut && loading && (
          <div className="mt-12 flex flex-col items-center justify-center gap-4 rounded-2xl border border-dashed border-border/80 px-6 py-16 text-center">
            <span className="flex size-12 items-center justify-center rounded-full bg-amber-500/10 text-amber-600 dark:text-amber-400">
              <ShieldCheck className="size-6" />
            </span>
            <p className="text-base font-semibold">Can't reach CoinNest</p>
            <p className="max-w-sm text-sm text-muted-foreground">
              We're having trouble connecting to the server. This usually
              resolves on its own — try refreshing the page.
            </p>
            <Button
              onClick={() => window.location.reload()}
              variant="outline"
              className="mt-2"
            >
              Try again
            </Button>
          </div>
        )}

        {/* Greeting */}
        <div className="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="flex items-center gap-1.5 text-sm text-muted-foreground">
              <CalendarDays className="size-4" />
              {format(new Date(), "EEEE, MMMM d")}
            </p>
            <h1 className="mt-1 text-2xl font-semibold tracking-tight sm:text-3xl">
              {greeting()}, {firstName}
            </h1>
          </div>
          <p className="flex items-center gap-1.5 text-sm text-muted-foreground">
            <ShieldCheck className="size-4 text-primary" />
            Your savings are private to you
          </p>
        </div>

        {/* First-run banner */}
        {isFirstRun && (
          <div className="mt-6 flex flex-col gap-4 rounded-2xl border border-primary/20 bg-gradient-to-br from-primary/10 via-background to-sky-500/10 p-6 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <p className="flex items-center gap-1.5 text-sm font-semibold text-primary">
                <Sparkles className="size-4" />
                Welcome to CoinNest
              </p>
              <p className="mt-1 max-w-xl text-sm text-muted-foreground">
                Start by logging any coin you set aside — even a small amount.
                Track your progress toward goals and watch your savings grow.
              </p>
            </div>
            <div className="flex shrink-0 gap-2">
              <AddSavingDialog
                goals={goalsList}
                buttonLabel="Log your first save"
              />
            </div>
          </div>
        )}

        {/* Stats */}
        <section className="mt-6 grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-4">
          {loading
            ? Array.from({ length: 4 }).map((_, i) => (
                <Card key={i} className="border-border/70 shadow-none">
                  <CardContent className="p-5">
                    <Skeleton className="h-4 w-20" />
                    <Skeleton className="mt-3 h-7 w-24" />
                    <Skeleton className="mt-2 h-3 w-28" />
                  </CardContent>
                </Card>
              ))
            : statCards.map((card) => (
                <Card
                  key={card.label}
                  className="border-border/70 shadow-none transition-shadow hover:shadow-sm"
                >
                  <CardContent className="p-5">
                    <span
                      className={cn(
                        "flex size-9 items-center justify-center rounded-lg",
                        card.accent,
                      )}
                    >
                      <card.icon className="size-4" />
                    </span>
                    <p className="mt-4 text-sm text-muted-foreground">
                      {card.label}
                    </p>
                    <p className="mt-0.5 text-xl font-semibold tracking-tight sm:text-2xl">
                      {card.value}
                    </p>
                    <p className="mt-1 truncate text-xs text-muted-foreground">
                      {card.sub}
                    </p>
                  </CardContent>
                </Card>
              ))}
        </section>

        {/* Chart */}
        <section className="mt-6">
          {loading ? (
            <Card className="border-border/70 shadow-none">
              <CardContent className="p-5">
                <Skeleton className="h-5 w-40" />
                <Skeleton className="mt-4 h-56 w-full" />
              </CardContent>
            </Card>
          ) : (
            <SavingsChart data={chartData} />
          )}
        </section>

        {/* Goals + recent activity */}
        <section className="mt-6 grid gap-6 lg:grid-cols-5">
          <div className="lg:col-span-3">
            {loading ? (
              <Card className="border-border/70 shadow-none">
                <CardContent className="p-5">
                  <Skeleton className="h-5 w-32" />
                  <Skeleton className="mt-4 h-24 w-full" />
                  <Skeleton className="mt-3 h-24 w-full" />
                </CardContent>
              </Card>
            ) : (
              <GoalsSection goals={goalsList} savedByGoal={savedByGoal} />
            )}
          </div>

          <div className="lg:col-span-2">
            <Card className="border-border/70 shadow-none">
              <CardHeader>
                <CardTitle className="text-base">Recent activity</CardTitle>
                <CardDescription>
                  Your latest savings entries
                </CardDescription>
              </CardHeader>
              <CardContent>
                {loading ? (
                  <div className="grid gap-3">
                    <Skeleton className="h-12 w-full" />
                    <Skeleton className="h-12 w-full" />
                    <Skeleton className="h-12 w-full" />
                  </div>
                ) : savingsList.length === 0 ? (
                  <div className="flex flex-col items-center justify-center gap-2 rounded-xl border border-dashed border-border/80 px-6 py-10 text-center">
                    <span className="flex size-10 items-center justify-center rounded-full bg-primary/10 text-primary">
                      <PiggyBank className="size-5" />
                    </span>
                    <p className="text-sm font-medium">Nothing logged yet</p>
                    <p className="max-w-xs text-sm text-muted-foreground">
                      Every entry appears here, newest first.
                    </p>
                  </div>
                ) : (
                  <ul className="grid gap-1">
                    {savingsList.slice(0, 6).map((entry) => (
                      <li
                        key={entry._id}
                        className="group flex items-center gap-3 rounded-xl px-2 py-2.5 transition-colors hover:bg-muted/60"
                      >
                        <span className="flex h-9 w-14 shrink-0 items-center justify-center rounded-lg bg-primary/10 font-mono text-xs font-semibold text-primary">
                          {entry.asset}
                        </span>
                        <div className="min-w-0 flex-1">
                          <p className="truncate text-sm font-medium">
                            {entry.note || `Saved in ${entry.asset}`}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {timeAgo(entry._creationTime)}
                          </p>
                        </div>
                        <p className="shrink-0 text-sm font-semibold tabular-nums">
                          +{formatUSD(entry.amountUsd)}
                        </p>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="size-7 shrink-0 text-muted-foreground opacity-0 transition-opacity hover:text-destructive group-hover:opacity-100"
                          aria-label="Delete entry"
                          onClick={() => handleDeleteSaving(entry._id)}
                        >
                          <Trash2 className="size-4" />
                        </Button>
                      </li>
                    ))}
                  </ul>
                )}
              </CardContent>
            </Card>
          </div>
        </section>

        {/* AI Coach + Meme Signal board */}
        <section className="mt-6 grid gap-6 lg:grid-cols-2">
          <AICoach />
          <MemeSignals />
        </section>

        {/* Footer */}
        <footer className="mt-16 flex flex-col items-center justify-between gap-3 border-t border-border/70 pt-6 text-xs text-muted-foreground sm:flex-row">
          <p>CoinNest — secure crypto savings tracking.</p>
          <div className="flex gap-4">
            <Link
              to="/privacy"
              className="transition-colors hover:text-foreground"
            >
              Privacy
            </Link>
            <Link
              to="/terms"
              className="transition-colors hover:text-foreground"
            >
              Terms
            </Link>
            <Link
              to="/contact"
              className="transition-colors hover:text-foreground"
            >
              Contact
            </Link>
          </div>
        </footer>
      </main>
    </div>
  );
}
