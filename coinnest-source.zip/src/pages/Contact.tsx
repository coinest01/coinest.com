import { useState } from "react";
import { Link } from "react-router";
import { ArrowLeft, ArrowRight, Mail, MessageSquare, Send } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { LogoWordmark } from "@/components/logo";
import { toast } from "sonner";

const contactMethods = [
  {
    icon: Mail,
    title: "Email",
    description: "For general questions, support, or privacy concerns",
    value: "support@coinnest.app",
    href: "mailto:support@coinnest.app",
  },
  {
    icon: MessageSquare,
    title: "Privacy requests",
    description: "To delete your account or data, or for GDPR requests",
    value: "privacy@coinnest.app",
    href: "mailto:privacy@coinnest.app",
  },
];

export default function Contact() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [subject, setSubject] = useState("");
  const [message, setMessage] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !email || !message) {
      toast.error("Please fill in your name, email, and message.");
      return;
    }

    const mailtoBody = encodeURIComponent(
      `Hi CoinNest team,\n\n${message}\n\n---\nName: ${name}\nEmail: ${email}`,
    );
    const mailtoUrl = `mailto:support@coinnest.app?subject=${encodeURIComponent(subject || "CoinNest support request")}&body=${mailtoBody}`;

    window.location.href = mailtoUrl;
    toast.success("Opening your email app to send the message.");
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Nav */}
      <header className="sticky top-0 z-40 border-b border-border/60 bg-background/85 backdrop-blur">
        <nav className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-4 px-4 sm:px-6">
          <Link to="/" aria-label="CoinNest home">
            <LogoWordmark markClassName="size-8" />
          </Link>
          <div className="flex items-center gap-2">
            <Button variant="outline" asChild>
              <Link to="/">
                <ArrowLeft className="size-4" />
                Back to home
              </Link>
            </Button>
            <Button asChild>
              <Link to="/auth">Sign in</Link>
            </Button>
          </div>
        </nav>
      </header>

      <main className="mx-auto max-w-3xl px-4 py-14 sm:px-6 sm:py-20">
        <p className="text-sm font-medium text-primary">Support</p>
        <h1 className="mt-3 text-3xl font-semibold tracking-tight sm:text-4xl">
          Get in touch
        </h1>
        <p className="mt-4 text-base leading-relaxed text-muted-foreground">
          Have a question, suggestion, or issue? We're a small team and we read
          every message. We aim to respond within 3 business days.
        </p>

        {/* Direct contact methods */}
        <div className="mt-10 grid gap-4 sm:grid-cols-2">
          {contactMethods.map((method) => (
            <a
              key={method.title}
              href={method.href}
              className="group flex flex-col rounded-2xl border border-border/70 bg-card p-6 transition-all hover:border-primary/25 hover:shadow-lg hover:shadow-blue-900/5"
            >
              <span className="flex size-10 items-center justify-center rounded-xl bg-primary/10 text-primary transition-transform group-hover:scale-110">
                <method.icon className="size-5" />
              </span>
              <h3 className="mt-4 text-base font-semibold">{method.title}</h3>
              <p className="mt-1 text-sm text-muted-foreground">
                {method.description}
              </p>
              <p className="mt-3 text-sm font-medium text-primary group-hover:underline">
                {method.value}
              </p>
            </a>
          ))}
        </div>

        {/* Contact form */}
        <Card className="mt-10 border-border/70">
          <CardHeader>
            <CardTitle className="text-lg">Send us a message</CardTitle>
            <CardDescription>
              Fill out the form below and it will open your email app with
              the details pre-filled.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="grid gap-4">
              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <label
                    htmlFor="contact-name"
                    className="mb-1.5 block text-sm font-medium"
                  >
                    Name
                  </label>
                  <Input
                    id="contact-name"
                    placeholder="Your name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    required
                  />
                </div>
                <div>
                  <label
                    htmlFor="contact-email"
                    className="mb-1.5 block text-sm font-medium"
                  >
                    Email
                  </label>
                  <Input
                    id="contact-email"
                    type="email"
                    placeholder="name@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                  />
                </div>
              </div>
              <div>
                <label
                  htmlFor="contact-subject"
                  className="mb-1.5 block text-sm font-medium"
                >
                  Subject
                </label>
                <Input
                  id="contact-subject"
                  placeholder="How can we help?"
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                />
              </div>
              <div>
                <label
                  htmlFor="contact-message"
                  className="mb-1.5 block text-sm font-medium"
                >
                  Message
                </label>
                <textarea
                  id="contact-message"
                  rows={5}
                  placeholder="Tell us what's on your mind..."
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  required
                  className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 resize-none"
                />
              </div>
              <Button type="submit" className="w-full sm:w-auto">
                <Send className="size-4" />
                Send message
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* FAQ redirect */}
        <div className="mt-10 rounded-2xl border border-border/70 bg-muted/40 p-6 text-center">
          <p className="text-sm font-semibold">Looking for quick answers?</p>
          <p className="mt-1 text-sm text-muted-foreground">
            Check our{" "}
            <a
              href="/#faq"
              className="font-medium text-primary hover:underline"
            >
              FAQ
            </a>{" "}
            for common questions about CoinNest.
          </p>
        </div>
      </main>

      <footer className="border-t border-border/60">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-3 px-4 py-6 text-xs text-muted-foreground sm:flex-row sm:px-6">
          <p>© 2026 CoinNest. Made for beginner savers.</p>
          <div className="flex gap-5">
            <Link to="/" className="transition-colors hover:text-foreground">
              Home
            </Link>
            <Link
              to="/privacy"
              className="transition-colors hover:text-foreground"
            >
              Privacy policy
            </Link>
            <Link
              to="/terms"
              className="transition-colors hover:text-foreground"
            >
              Terms of Service
            </Link>
          </div>
        </div>
      </footer>
    </div>
  );
}
