import { Link } from "react-router";
import {
  ArrowLeft,
  Database,
  KeyRound,
  Lock,
  ShieldCheck,
  Timer,
} from "lucide-react";

import { Button } from "@/components/ui/button";
import { LogoWordmark } from "@/components/logo";

const sections = [
  {
    title: "1. Overview",
    body: "CoinNest is a personal crypto savings tracker. This policy explains what information we collect, how we protect it, and the choices you have. The short version: we collect as little as possible, we never sell your data, and your savings entries are only ever visible to you.",
  },
  {
    title: "2. Information we collect",
    body: "Your email address (used to send you a one-time sign-in code). Savings entries you create — the USD amount, the coin, an optional note, and any goal you link them to. Goals you create — name, target, and color. Questions you ask the AI Coach, plus a technical log of each AI request (model, token count, estimated cost, and response time) so we can monitor quality and spending. Basic technical data such as server logs and timestamps that Convex (our database provider) needs to operate the service.",
  },
  {
    title: "3. How we use it",
    body: "We use your email only to authenticate you and send sign-in codes. Your savings entries and goals are used only to display your own tracker back to you. Your AI Coach questions are used only to generate the answer shown to you and to improve the feature's reliability — the coach is grounded in your own savings numbers, which are never shared with third parties in a form that identifies you. We do not use your data for advertising, profiling, or anything else.",
  },
  {
    title: "4. How we protect your data",
    body: "CoinNest treats your privacy as a core feature:",
    items: [
      {
        icon: KeyRound,
        title: "Rate-limited sign-in",
        body: "Sign-in is protected by anti-brute-force rate limiting: after 5 failed verification attempts within an hour, the account pauses and cools down before allowing more attempts. This makes automated attacks impractical.",
      },
      {
        icon: Timer,
        title: "Short-lived one-time codes",
        body: "Sign-in codes expire after 15 minutes and can be used once. There are no passwords to leak or reuse.",
      },
      {
        icon: ShieldCheck,
        title: "Server-side access control",
        body: "Every backend query and mutation verifies your identity. The server only ever returns or modifies data that belongs to the signed-in user — it is impossible for one user to read another user's savings through the app.",
      },
      {
        icon: Lock,
        title: "Encryption in transit & at rest",
        body: "All traffic is encrypted in transit (TLS). Your data is stored in a Convex database, encrypted at rest and isolated per user.",
      },
      {
        icon: Database,
        title: "Minimal data retention",
        body: "Verification codes are stored only for their short expiry window. We do not run analytics trackers, cookies for advertising, or third-party scripts on the app.",
      },
    ],
  },
  {
    title: "5. Data sharing",
    body: "We do not sell, rent, or trade your personal information. The only third parties involved are the infrastructure providers required to run the service: Convex (database and backend hosting, including server logs), the email delivery service used to send your one-time codes, Perplexity (the AI provider that powers the AI Coach — it receives only the question you asked and a short, anonymized summary of your savings totals, never your email or identity), and CoinGecko (the public market-data source used for the Meme Signal board). Each receives only the minimum data needed to do its job.",
  },
  {
    title: "6. Your choices and rights",
    body: "Delete any savings entry or goal at any time directly in the app — changes take effect immediately. To delete your entire account and all associated data, email us at privacy@coinnest.app and we'll remove everything within 30 days. You can also simply stop using the app; your data is never used for anything beyond your own tracker.",
  },
  {
    title: "7. Children",
    body: "CoinNest is not directed at children under 13, and we do not knowingly collect information from them. If you believe a child has provided us personal information, contact us and we'll delete it.",
  },
  {
    title: "8. Changes to this policy",
    body: "If we change this policy, we'll update the date below and, for significant changes, notify you by email. Continued use of CoinNest after changes means you accept the updated policy.",
  },
  {
    title: "9. Contact",
    body: "Questions about this policy or your data? Email privacy@coinnest.app or visit our Contact page. We aim to reply within 3 business days. You can also review our Terms of Service for how we operate the service.",
  },
];

export default function Privacy() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Nav */}
      <header className="sticky top-0 z-40 border-b border-border/60 bg-background/85 backdrop-blur">
        <nav className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-4 px-4 sm:px-6">
          <Link to="/" aria-label="CoinNest home">
            <LogoWordmark markClassName="size-8" />
          </Link>
          <div className="flex items-center gap-2">
            <Button variant="outline" asChild>
              <Link to="/">
                <ArrowLeft className="size-4" />
                Back to home
              </Link>
            </Button>
            <Button asChild>
              <Link to="/auth">Sign in</Link>
            </Button>
          </div>
        </nav>
      </header>

      <main className="mx-auto max-w-3xl px-4 py-14 sm:px-6 sm:py-20">
        <p className="text-sm font-medium text-primary">
          Legal · Last updated August 17, 2026
        </p>
        <h1 className="mt-3 text-3xl font-semibold tracking-tight sm:text-4xl">
          Privacy Policy
        </h1>
        <p className="mt-4 text-base leading-relaxed text-muted-foreground">
          CoinNest is a personal savings tracker, not a social network. We
          designed it so your savings data is yours alone — read on for exactly
          how that works.
        </p>

        <div className="mt-12 grid gap-10">
          {sections.map((section) => (
            <section key={section.title} id={section.title.split(" ")[0]}>
              <h2 className="text-xl font-semibold tracking-tight">
                {section.title}
              </h2>
              <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
                {section.body}
              </p>
              {section.items && (
                <ul className="mt-5 grid gap-4">
                  {section.items.map((item) => (
                    <li
                      key={item.title}
                      className="rounded-xl border border-border/70 bg-card p-4"
                    >
                      <div className="flex items-start gap-3">
                        <span className="mt-0.5 flex size-8 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary">
                          <item.icon className="size-4" />
                        </span>
                        <div>
                          <p className="text-sm font-semibold">{item.title}</p>
                          <p className="mt-1 text-sm leading-relaxed text-muted-foreground">
                            {item.body}
                          </p>
                        </div>
                      </div>
                    </li>
                  ))}
                </ul>
              )}
            </section>
          ))}
        </div>

        <div className="mt-14 rounded-2xl border border-primary/20 bg-gradient-to-br from-primary/10 via-background to-sky-500/10 p-6 text-center">
          <p className="text-sm font-semibold">Still have questions?</p>
          <p className="mt-1 text-sm text-muted-foreground">
            Email us at privacy@coinnest.app — a human will get back to you.
          </p>
        </div>
      </main>

      <footer className="border-t border-border/60">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-3 px-4 py-6 text-xs text-muted-foreground sm:flex-row sm:px-6">
          <p>© 2026 CoinNest. Made for beginner savers.</p>
          <div className="flex gap-5">
            <Link to="/" className="transition-colors hover:text-foreground">
              Home
            </Link>
            <Link to="/terms" className="transition-colors hover:text-foreground">
              Terms of Service
            </Link>
            <Link to="/contact" className="transition-colors hover:text-foreground">
              Contact
            </Link>
            <Link
              to="/auth"
              className="transition-colors hover:text-foreground"
            >
              Sign in
            </Link>
          </div>
        </div>
      </footer>
    </div>
  );
}
