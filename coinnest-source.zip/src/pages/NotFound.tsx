import { Link } from "react-router";
import { motion } from "framer-motion";
import { ArrowLeft, Compass } from "lucide-react";

import { Button } from "@/components/ui/button";
import { LogoWordmark } from "@/components/logo";

export default function NotFound() {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="flex min-h-screen flex-col bg-background text-foreground"
    >
      <header className="border-b border-border/60">
        <div className="mx-auto flex h-16 max-w-6xl items-center px-4 sm:px-6">
          <Link to="/" aria-label="CoinNest home">
            <LogoWordmark markClassName="size-8" />
          </Link>
        </div>
      </header>

      <div className="flex flex-1 items-center justify-center px-4">
        <div className="text-center">
          <span className="mx-auto flex size-14 items-center justify-center rounded-2xl bg-primary/10 text-primary">
            <Compass className="size-7" />
          </span>
          <h1 className="mt-6 text-6xl font-semibold tracking-tight">404</h1>
          <p className="mt-3 text-lg text-muted-foreground">
            The page you're looking for doesn't exist or has been moved.
          </p>
          <div className="mt-8 flex justify-center">
            <Button asChild>
              <Link to="/">
                <ArrowLeft className="size-4" />
                Back to CoinNest
              </Link>
            </Button>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
